# Hackerpraktikum
##EU:
Artikel 8 der Grundrechtecharta  
"Jede Person hat das Recht auf Achtung ihres Privat- und Familienlebens, ihrer Wohnung und ihrer Korrespondenz."
##Deutschland:
###STGB:
§202 Verletzung des Briefgeheimnisses  
§202a Ausspähen von Daten  
§202b Abfangen von Daten  
§202c Vorbereiten des Ausspähen und Abfangen von Daten  
§202d Datenhehlerei  
###BDSG:

##Uni Trier:
Teilgrundordnung https://www.uni-trier.de/index.php?id=6397  
CIP pool der Informatik: 
